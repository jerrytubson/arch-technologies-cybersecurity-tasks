from scapy.all import *
from datetime import datetime

LOG_FILE = "packets.log"

def process_packet(packet):
    timestamp = datetime.now().strftime("%H:%M:%S")

    if packet.haslayer(IP):
        src = packet[IP].src
        dst = packet[IP].dst

        if packet.haslayer(TCP):
            proto = "TCP"
        elif packet.haslayer(UDP):
            proto = "UDP"
        elif packet.haslayer(ICMP):
            proto = "ICMP"
        else:
            proto = "OTHER"

        line = f"[{timestamp}] {proto} {src} -> {dst}"
        print(line)

        with open(LOG_FILE, "a") as f:
            f.write(line + "\n")

print("Sniffer started... Press CTRL+C to stop")

sniff(prn=process_packet, store=False)

