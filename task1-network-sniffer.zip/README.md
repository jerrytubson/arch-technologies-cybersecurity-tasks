TASK 1 – BASIC NETWORK SNIFFER
=============================

Objective:
To understand how network packets flow and how traffic can be analyzed.

Tools Used:
- Python
- Scapy
- Kali Linux (WSL)

Description:
A packet sniffer was developed using Scapy to capture live network traffic.
The program extracts and displays source IP, destination IP, and protocol information.

Features:
- Captures TCP/UDP/ICMP packets
- Logs packets to packets.log
- Saves capture to capture.pcap for Wireshark analysis

Security Learning Outcome:
Helps understand packet structures, traffic inspection, and network monitoring techniques used in SOC environments.


