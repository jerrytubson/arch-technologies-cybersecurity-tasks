TASK 2 – KEYLOGGER SIMULATION
=============================

Objective:
To understand how keystroke logging attacks work and the risks they pose.

Tools Used:
- Python 3
- pynput library

Description:
A basic keylogger was implemented that captures global keyboard input using system hooks.
All keystrokes are stored inside keys.log.

Features:
- Captures system-wide keystrokes
- Logs characters and special keys
- Stops safely using ESC
- Demonstrates how credentials can be stolen

Security Learning Outcome:
This project shows why endpoint protection, antivirus, and secure practices are important to prevent keylogging attacks.

Environment:
Windows OS
